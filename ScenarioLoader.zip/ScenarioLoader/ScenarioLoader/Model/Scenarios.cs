﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScenarioLoader.ViewModel;

namespace ScenarioLoader.Model
{
    public class Scenarios : ViewModelBase
    {
        private string folderName;
        private List<Scenarios> subScenarios;
        private List<Scenario> subSceanrioNames;

        public string FolderName
        {
            get
            {
                return this.folderName;
            }
            set
            {
                this.folderName = value;
                this.OnPropertyRaised();
            }
        }
        public List<Scenarios> SubScenarios {
            get
            {
               return this.subScenarios;
            }
            set
            {
                this.subScenarios = value;
                this.OnPropertyRaised();
            }
        }


        public List<Scenario> SubSceanrioNames {
            get
            {
                return this.subSceanrioNames;
            }
            set
            {
                this.subSceanrioNames = value;
                this.OnPropertyRaised();
            }
        }

        public Scenarios()
        {
            this.SubSceanrioNames = new List<Scenario>();
            this.SubScenarios = new List<Scenarios>();
        }
    }
}
