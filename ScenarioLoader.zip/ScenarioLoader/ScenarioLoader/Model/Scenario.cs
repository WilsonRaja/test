﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScenarioLoader.ViewModel;

namespace ScenarioLoader.Model
{
    public class Scenario : ViewModelBase
    {
        private string name;

        public string Name {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
                this.OnPropertyRaised();
            }
        }
    }
}
