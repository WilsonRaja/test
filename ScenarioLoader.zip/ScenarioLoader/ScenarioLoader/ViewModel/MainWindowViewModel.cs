﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ScenarioLoader.Model;

namespace ScenarioLoader.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        private Scenarios scenarios;

        #region Properties

        public Scenarios Scenarios {
            get
            {
                return this.scenarios;
            }
            set
            {
                this.scenarios = value;
                this.OnPropertyRaised();
            }
        }

        #endregion
        #region Constructor
        public MainWindowViewModel()
        {
            this.Scenarios = new Scenarios();
            LoadXmlFile();
        }

        #endregion

        #region Private Methods
        private void LoadXmlFile()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(@".\Scenarios.xml");
            //XmlNode node = doc.DocumentElement.RemoveAttributeAt;
            XmlNodeList xmlNodeList = doc.SelectNodes("/Scenarios/Folder");
            this.scenarios.FolderName = "Scenarios";
            LoadFolders(xmlNodeList, this.scenarios);
            this.OnPropertyRaised("Scenarios");
        }

        private void LoadFolders(XmlNodeList xmlNodeList, Scenarios scenarios)
        {
            foreach (XmlNode node in xmlNodeList)
            {
                if(node.Name == "Folder")
                {
                    Scenarios currentScenarios = new Scenarios();
                    currentScenarios.FolderName = node.Attributes["Name"].InnerText;
                    scenarios.SubScenarios.Add(currentScenarios);
                    LoadFolders(node.ChildNodes, currentScenarios);
                }
                else
                {
                    Scenario currentScenario = new Scenario();
                    currentScenario.Name = node.Attributes["Name"].InnerText;
                    scenarios.SubSceanrioNames.Add(currentScenario);
                }
            }
        }

        #endregion

    }
}
